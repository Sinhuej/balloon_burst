package com.example.balloon_burst

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
